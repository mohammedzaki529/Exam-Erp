<?php
// add_result.php - Redirect to student result portal
header("Location: result.php");
exit;
