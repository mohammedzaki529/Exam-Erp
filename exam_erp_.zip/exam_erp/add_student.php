<?php
// add_student.php - Register New Student
require_once 'db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name'] ?? '');
    $roll_number = trim($_POST['roll_number'] ?? '');
    $course_id = (int)($_POST['course_id'] ?? 0);
    $semester = (int)($_POST['semester'] ?? 1);

    if (empty($name) || empty($roll_number) || $course_id <= 0) {
        $message = "<div class='alert-danger'>Please fill in all required fields!</div>";
    } else {
        // Check if roll number already exists
        $check = $conn->query("SELECT student_id FROM students WHERE roll_number = '$roll_number'");
        if ($check && $check->num_rows > 0) {
            $message = "<div class='alert-danger'>Roll Number ($roll_number) already registered!</div>";
        } else {
            $sql = "INSERT INTO students (name, roll_number, course_id, semester) VALUES ('$name', '$roll_number', $course_id, $semester)";
            if ($conn->query($sql)) {
                $message = "<div class='alert-success'>Student added successfully! <a href='students.php'>View Students List</a></div>";
            } else {
                $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
            }
        }
    }
}

// Fetch Courses for Dropdown
$courses = $conn->query("SELECT * FROM courses ORDER BY course_name ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Student - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container" style="max-width: 500px;">
    <h2>Add New Student</h2>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <form method="POST" action="add_student.php">
        <div class="form-group">
            <label>Student Full Name:</label>
            <input type="text" name="name" required placeholder="Enter student name">
        </div>

        <div class="form-group">
            <label>Roll Number:</label>
            <input type="text" name="roll_number" required placeholder="e.g. 24BCA101">
        </div>

        <div class="form-group">
            <label>Course:</label>
            <select name="course_id" required>
                <option value="">-- Select Course --</option>
                <?php while ($row = $courses->fetch_assoc()): ?>
                    <option value="<?php echo $row['course_id']; ?>">
                        <?php echo $row['course_name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Semester:</label>
            <select name="semester" required>
                <option value="1">Semester 1</option>
                <option value="2">Semester 2</option>
                <option value="3">Semester 3</option>
                <option value="4">Semester 4</option>
                <option value="5">Semester 5</option>
                <option value="6">Semester 6</option>
            </select>
        </div>

        <div style="margin-top: 20px;">
            <input type="submit" value="Save Student" class="btn btn-success">
            <a href="students.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

</body>
</html>
