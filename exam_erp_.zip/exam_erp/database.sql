-- Database SQL Dump for College Exam ERP Project
-- Database Name: exam

CREATE DATABASE IF NOT EXISTS `exam`;
USE `exam`;

-- 1. Courses Table
CREATE TABLE IF NOT EXISTS `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `courses` (`course_id`, `course_name`) VALUES
(1, 'BCA (Bachelor of Computer Applications)'),
(2, 'B.Sc (Computer Science)'),
(3, 'BBA (Bachelor of Business Administration)'),
(4, 'MCA (Master of Computer Applications)');

-- 2. Students Table
CREATE TABLE IF NOT EXISTS `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `roll_number` varchar(50) NOT NULL UNIQUE,
  `course_id` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `students` (`student_id`, `name`, `roll_number`, `course_id`, `semester`) VALUES
(1, 'Rahul Sharma', '24BCA101', 1, 1),
(2, 'Priya Singh', '24BCA102', 1, 1),
(3, 'Amit Kumar', '24BCA103', 1, 1);

-- 3. Subjects Table
CREATE TABLE IF NOT EXISTS `subjects` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(100) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `subjects` (`subject_id`, `subject_name`, `course_id`, `semester`) VALUES
(1, 'C Programming', 1, 1),
(2, 'Mathematics I', 1, 1),
(3, 'Digital Electronics', 1, 1),
(4, 'Communication Skills', 1, 1);

-- 4. Exam Results Table
CREATE TABLE IF NOT EXISTS `exam_results` (
  `result_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `internal_marks` int(11) NOT NULL,
  `external_marks` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`result_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `exam_results` (`result_id`, `student_id`, `subject_id`, `internal_marks`, `external_marks`, `total_marks`, `grade`, `status`) VALUES
(1, 1, 1, 25, 60, 85, 'A+', 'Pass'),
(2, 1, 2, 22, 55, 77, 'A', 'Pass'),
(3, 1, 3, 20, 48, 68, 'B', 'Pass');
