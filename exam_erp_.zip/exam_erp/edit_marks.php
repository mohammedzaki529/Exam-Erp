<?php
// edit_marks.php - Edit Student Exam Marks
require_once 'db.php';

$message = "";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: manage_marks.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $internal = (int)($_POST['internal_marks'] ?? 0);
    $external = (int)($_POST['external_marks'] ?? 0);

    if ($internal < 0) $internal = 0;
    if ($internal > 30) $internal = 30;
    if ($external < 0) $external = 0;
    if ($external > 70) $external = 70;

    $total = $internal + $external;

    if ($internal < 10 || $external < 25 || $total < 40) {
        $status = "Fail";
        $grade = "F";
    } else {
        $status = "Pass";
        if ($total >= 85) $grade = "A+";
        elseif ($total >= 75) $grade = "A";
        elseif ($total >= 60) $grade = "B";
        elseif ($total >= 50) $grade = "C";
        else $grade = "D";
    }

    $sql = "UPDATE exam_results SET internal_marks = $internal, external_marks = $external, total_marks = $total, grade = '$grade', status = '$status' WHERE result_id = $id";
    if ($conn->query($sql)) {
        $message = "<div class='alert-success'>Marks updated successfully! Total: $total/100 | Grade: $grade | Status: $status (<a href='manage_marks.php'>Back to Marks List</a>)</div>";
    } else {
        $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
    }
}

// Fetch Result Details
$query = "
    SELECT er.*, s.name as student_name, s.roll_number, sub.subject_name, sub.semester
    FROM exam_results er
    JOIN students s ON er.student_id = s.student_id
    JOIN subjects sub ON er.subject_id = sub.subject_id
    WHERE er.result_id = $id
";
$res = $conn->query($query);
if (!$res || $res->num_rows == 0) {
    die("Record not found!");
}
$record = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Marks - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container" style="max-width: 520px;">
    <h2>Edit Exam Marks</h2>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <div style="background: #f8f9fa; border: 1px solid #ddd; padding: 12px; margin-bottom: 20px;">
        <p style="margin: 0 0 6px 0;"><strong>Student:</strong> <?php echo htmlspecialchars($record['student_name']); ?> (Roll: <?php echo htmlspecialchars($record['roll_number']); ?>)</p>
        <p style="margin: 0;"><strong>Subject:</strong> <?php echo htmlspecialchars($record['subject_name']); ?> (Semester <?php echo $record['semester']; ?>)</p>
    </div>

    <form method="POST" action="edit_marks.php?id=<?php echo $id; ?>">
        <div class="form-group">
            <label>Internal Marks (Max 30):</label>
            <input type="number" name="internal_marks" min="0" max="30" value="<?php echo $record['internal_marks']; ?>" required>
        </div>

        <div class="form-group">
            <label>External Marks (Max 70):</label>
            <input type="number" name="external_marks" min="0" max="70" value="<?php echo $record['external_marks']; ?>" required>
        </div>

        <div style="margin-top: 20px;">
            <input type="submit" value="Update Marks" class="btn btn-success">
            <a href="manage_marks.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

</body>
</html>
