<?php
// edit_student.php - Edit Student Details
require_once 'db.php';

$message = "";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: students.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name'] ?? '');
    $roll_number = trim($_POST['roll_number'] ?? '');
    $course_id = (int)($_POST['course_id'] ?? 0);
    $semester = (int)($_POST['semester'] ?? 1);

    if (empty($name) || empty($roll_number) || $course_id <= 0) {
        $message = "<div class='alert-danger'>Please fill in all fields!</div>";
    } else {
        // Check duplicate roll number for other students
        $check = $conn->query("SELECT student_id FROM students WHERE roll_number = '$roll_number' AND student_id != $id");
        if ($check && $check->num_rows > 0) {
            $message = "<div class='alert-danger'>This Roll Number ($roll_number) is already assigned to another student!</div>";
        } else {
            $sql = "UPDATE students SET name = '$name', roll_number = '$roll_number', course_id = $course_id, semester = $semester WHERE student_id = $id";
            if ($conn->query($sql)) {
                $message = "<div class='alert-success'>Student updated successfully! <a href='students.php'>Back to Students List</a></div>";
            } else {
                $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
            }
        }
    }
}

// Fetch Student Data
$studentRes = $conn->query("SELECT * FROM students WHERE student_id = $id");
if (!$studentRes || $studentRes->num_rows == 0) {
    die("Student not found!");
}
$student = $studentRes->fetch_assoc();

// Fetch Courses
$courses = $conn->query("SELECT * FROM courses ORDER BY course_name ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Student - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container" style="max-width: 500px;">
    <h2>Edit Student Details</h2>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <form method="POST" action="edit_student.php?id=<?php echo $id; ?>">
        <div class="form-group">
            <label>Student Full Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Roll Number:</label>
            <input type="text" name="roll_number" value="<?php echo htmlspecialchars($student['roll_number']); ?>" required>
        </div>

        <div class="form-group">
            <label>Course:</label>
            <select name="course_id" required>
                <option value="">-- Select Course --</option>
                <?php while ($c = $courses->fetch_assoc()): ?>
                    <option value="<?php echo $c['course_id']; ?>" <?php if ($c['course_id'] == $student['course_id']) echo 'selected'; ?>>
                        <?php echo $c['course_name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Semester:</label>
            <select name="semester" required>
                <?php for ($i = 1; $i <= 6; $i++): ?>
                    <option value="<?php echo $i; ?>" <?php if ($i == $student['semester']) echo 'selected'; ?>>
                        Semester <?php echo $i; ?>
                    </option>
                <?php endfor; ?>
            </select>
        </div>

        <div style="margin-top: 20px;">
            <input type="submit" value="Update Student" class="btn btn-success">
            <a href="students.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

</body>
</html>
