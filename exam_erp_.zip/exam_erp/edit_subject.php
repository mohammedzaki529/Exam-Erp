<?php
// edit_subject.php - Edit Subject Details
require_once 'db.php';

$message = "";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: subjects.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject_name = trim($_POST['subject_name'] ?? '');
    $course_id = (int)($_POST['course_id'] ?? 0);
    $semester = (int)($_POST['semester'] ?? 1);

    if (empty($subject_name) || $course_id <= 0) {
        $message = "<div class='alert-danger'>Please fill in all fields!</div>";
    } else {
        $sql = "UPDATE subjects SET subject_name = '$subject_name', course_id = $course_id, semester = $semester WHERE subject_id = $id";
        if ($conn->query($sql)) {
            $message = "<div class='alert-success'>Subject updated successfully! <a href='subjects.php'>Back to Subjects</a></div>";
        } else {
            $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}

// Fetch Subject Details
$subRes = $conn->query("SELECT * FROM subjects WHERE subject_id = $id");
if (!$subRes || $subRes->num_rows == 0) {
    die("Subject not found!");
}
$subject = $subRes->fetch_assoc();

// Fetch Courses
$courses = $conn->query("SELECT * FROM courses ORDER BY course_name ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Subject - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container" style="max-width: 500px;">
    <h2>Edit Subject Details</h2>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <form method="POST" action="edit_subject.php?id=<?php echo $id; ?>">
        <div class="form-group">
            <label>Subject / Paper Name:</label>
            <input type="text" name="subject_name" value="<?php echo htmlspecialchars($subject['subject_name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Course:</label>
            <select name="course_id" required>
                <option value="">-- Select Course --</option>
                <?php while ($c = $courses->fetch_assoc()): ?>
                    <option value="<?php echo $c['course_id']; ?>" <?php if ($c['course_id'] == $subject['course_id']) echo 'selected'; ?>>
                        <?php echo $c['course_name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Semester:</label>
            <select name="semester" required>
                <?php for ($i = 1; $i <= 6; $i++): ?>
                    <option value="<?php echo $i; ?>" <?php if ($i == $subject['semester']) echo 'selected'; ?>>
                        Semester <?php echo $i; ?>
                    </option>
                <?php endfor; ?>
            </select>
        </div>

        <div style="margin-top: 20px;">
            <input type="submit" value="Update Subject" class="btn btn-success">
            <a href="subjects.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

</body>
</html>
