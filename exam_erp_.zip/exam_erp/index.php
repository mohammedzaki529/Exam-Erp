<?php
// index.php - Admin Dashboard
require_once 'db.php';

// Total system summary counts
$totalStudents = 0;
$totalSubjects = 0;
$totalCourses  = 0;
$totalResults  = 0;

$r1 = $conn->query("SELECT COUNT(*) FROM students");
if ($r1) { $totalStudents = (int)$r1->fetch_row()[0]; }

$r2 = $conn->query("SELECT COUNT(*) FROM subjects");
if ($r2) { $totalSubjects = (int)$r2->fetch_row()[0]; }

$r3 = $conn->query("SELECT COUNT(*) FROM courses");
if ($r3) { $totalCourses = (int)$r3->fetch_row()[0]; }

$r4 = $conn->query("SELECT COUNT(*) FROM exam_results");
if ($r4) { $totalResults = (int)$r4->fetch_row()[0]; }

// Semesters 1 to 6 template (so graph stays clean, balanced and properly proportioned)
$maxSem = 6;
$resMax1 = $conn->query("SELECT MAX(semester) as m FROM students");
if ($resMax1 && $row = $resMax1->fetch_assoc()) {
    if ((int)$row['m'] > $maxSem) $maxSem = (int)$row['m'];
}
$resMax2 = $conn->query("SELECT MAX(semester) as m FROM subjects");
if ($resMax2 && $row = $resMax2->fetch_assoc()) {
    if ((int)$row['m'] > $maxSem) $maxSem = (int)$row['m'];
}

$allSemesters = [];
for ($i = 1; $i <= $maxSem; $i++) {
    $allSemesters[$i] = 0;
}

// Students count by semester
$studentData = $allSemesters;
$resStudents = $conn->query("SELECT semester, COUNT(*) AS total FROM students GROUP BY semester");
if ($resStudents) {
    while ($row = $resStudents->fetch_assoc()) {
        $studentData[(int)$row['semester']] = (int)$row['total'];
    }
}

// Subjects count by semester
$subjectData = $allSemesters;
$resSubjects = $conn->query("SELECT semester, COUNT(*) AS total FROM subjects GROUP BY semester");
if ($resSubjects) {
    while ($row = $resSubjects->fetch_assoc()) {
        $subjectData[(int)$row['semester']] = (int)$row['total'];
    }
}

$semLabels = [];
$studentCounts = [];
$subjectCounts = [];
foreach ($allSemesters as $sem => $val) {
    $semLabels[] = "Sem " . $sem;
    $studentCounts[] = $studentData[$sem];
    $subjectCounts[] = $subjectData[$sem];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exam ERP - Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 25px;
        }
        .stat-card {
            background: #ffffff;
            border: 1px solid #e0e6ed;
            border-radius: 8px;
            padding: 16px;
            text-align: center;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
        }
        .stat-num {
            font-size: 28px;
            font-weight: bold;
            color: #2c3e50;
        }
        .stat-label {
            font-size: 13px;
            color: #7f8c8d;
            margin-top: 5px;
            font-weight: 500;
        }
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }
        .chart-card {
            background: #ffffff;
            border: 1px solid #e0e6ed;
            border-radius: 8px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .chart-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        .chart-header h4 {
            margin: 0;
            font-size: 15px;
            color: #2c3e50;
        }
        .badge {
            font-size: 11px;
            padding: 3px 10px;
            border-radius: 12px;
            font-weight: bold;
        }
        .badge-blue { background: #e0f2fe; color: #0369a1; }
        .badge-green { background: #dcfce7; color: #15803d; }
        .chart-wrapper {
            position: relative;
            height: 250px;
            width: 100%;
        }
        .menu-list {
            list-style: none;
            padding: 0;
        }
        .menu-list li {
            padding: 12px 0;
            border-bottom: 1px solid #eeeeee;
        }
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container">
    <h2>Examination ERP System - Dashboard</h2>
    <p>Welcome to the College Examination and Result Management System.</p>
    <hr style="border: 0; border-top: 1px solid #ddd; margin: 15px 0 20px 0;">

    <!-- System Stats -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-num"><?php echo $totalStudents; ?></div>
            <div class="stat-label">Total Students</div>
        </div>
        <div class="stat-card">
            <div class="stat-num"><?php echo $totalSubjects; ?></div>
            <div class="stat-label">Total Subjects</div>
        </div>
        <div class="stat-card">
            <div class="stat-num"><?php echo $totalCourses; ?></div>
            <div class="stat-label">Total Courses</div>
        </div>
        <div class="stat-card">
            <div class="stat-num"><?php echo $totalResults; ?></div>
            <div class="stat-label">Recorded Results</div>
        </div>
    </div>

    <!-- Semester Charts -->
    <h3>Semester Analytics</h3>
    <div class="charts-grid">
        <div class="chart-card">
            <div class="chart-header">
                <h4>Students by Semester</h4>
                <span class="badge badge-blue">Students</span>
            </div>
            <div class="chart-wrapper">
                <canvas id="studentsSemesterChart"></canvas>
            </div>
        </div>
        <div class="chart-card">
            <div class="chart-header">
                <h4>Subjects per Semester</h4>
                <span class="badge badge-green">Subjects</span>
            </div>
            <div class="chart-wrapper">
                <canvas id="subjectsSemesterChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Quick Navigation Modules -->
    <h3>Quick Navigation</h3>
    <ul class="menu-list">
        <li>
            <strong>1. Students Management:</strong> 
            <a href="add_student.php" class="btn btn-sm btn-success">+ Add Student</a> 
            <a href="students.php" class="btn btn-sm">View Students List</a>
        </li>
        <li>
            <strong>2. Course Subjects:</strong> 
            <a href="subjects.php" class="btn btn-sm">Manage Subjects</a>
        </li>
        <li>
            <strong>3. Examination Marks:</strong> 
            <a href="marks.php" class="btn btn-sm btn-success">+ Enter Marks</a> 
            <a href="manage_marks.php" class="btn btn-sm">View Marks List</a>
        </li>
        <li>
            <strong>4. Student Result Portal:</strong> 
            <a href="result.php" class="btn btn-sm btn-secondary">Search Marksheet by Roll No</a>
        </li>
    </ul>
</div>

<script>
const semLabels = <?php echo json_encode($semLabels); ?>;

// Students Chart
const studentCtx = document.getElementById('studentsSemesterChart').getContext('2d');
new Chart(studentCtx, {
    type: 'bar',
    data: {
        labels: semLabels,
        datasets: [{
            label: 'Total Students',
            data: <?php echo json_encode($studentCounts); ?>,
            backgroundColor: '#3498db',
            borderColor: '#2980b9',
            borderWidth: 1,
            borderRadius: 6,
            maxBarThickness: 38
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'Students: ' + context.parsed.y;
                    }
                }
            }
        },
        scales: {
            x: {
                grid: { display: false }
            },
            y: {
                beginAtZero: true,
                ticks: {
                    precision: 0,
                    stepSize: 1
                },
                grid: {
                    color: '#f0f3f6'
                }
            }
        }
    }
});

// Subjects Chart
const subjectCtx = document.getElementById('subjectsSemesterChart').getContext('2d');
new Chart(subjectCtx, {
    type: 'bar',
    data: {
        labels: semLabels,
        datasets: [{
            label: 'Total Subjects',
            data: <?php echo json_encode($subjectCounts); ?>,
            backgroundColor: '#2ecc71',
            borderColor: '#27ae60',
            borderWidth: 1,
            borderRadius: 6,
            maxBarThickness: 38
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'Subjects: ' + context.parsed.y;
                    }
                }
            }
        },
        scales: {
            x: {
                grid: { display: false }
            },
            y: {
                beginAtZero: true,
                ticks: {
                    precision: 0,
                    stepSize: 1
                },
                grid: {
                    color: '#f0f3f6'
                }
            }
        }
    }
});
</script>

</body>
</html>
