<?php
// login.php - Exam ERP Login Page
session_start();
require_once 'db.php';

$error = '';

// Jab submit button par click kare tab process hoga aur redirect karega
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username !== '' && $password !== '') {
        // Username aur password enter karne ke baad login session create karo
        $_SESSION['user_id']  = 1;
        $_SESSION['username'] = $username;
        $_SESSION['role']     = 'admin';

        // Submit button click karne par index.php par redirect
        header("Location: index.php");
        exit;
    } else {
        $error = "Please enter both username and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam ERP - Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: #f4f6f9;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            background: #ffffff;
            border: 1px solid #e0e6ed;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
        }
        .login-card h2 {
            margin: 0 0 6px 0;
            color: #2c3e50;
            text-align: center;
            font-size: 22px;
        }
        .login-subtitle {
            margin: 0 0 20px 0;
            color: #7f8c8d;
            font-size: 13px;
            text-align: center;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            font-size: 13px;
            color: #34495e;
        }
        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccd5df;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .form-group input:focus {
            outline: none;
            border-color: #3498db;
        }
        .btn-login {
            width: 100%;
            padding: 11px;
            background: #2c3e50;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-login:hover {
            background: #1a252f;
        }
        .alert-error {
            background: #fdecea;
            color: #c0392b;
            border: 1px solid #f5c6cb;
            padding: 10px 12px;
            border-radius: 5px;
            margin-bottom: 16px;
            font-size: 13px;
            text-align: center;
        }
        .divider {
            position: relative;
            text-align: center;
            margin: 22px 0 18px 0;
        }
        .divider::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            width: 100%;
            height: 1px;
            background: #e2e8f0;
        }
        .divider span {
            position: relative;
            background: #ffffff;
            padding: 0 12px;
            color: #94a3b8;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .result-box {
            background: #f8fafc;
            border: 1px dashed #cbd5e1;
            border-radius: 6px;
            padding: 14px;
            text-align: center;
        }
        .result-box p {
            margin: 0 0 10px 0;
            font-size: 13px;
            color: #475569;
        }
        .btn-result {
            display: inline-block;
            width: 100%;
            box-sizing: border-box;
            padding: 9px 12px;
            background: #27ae60;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            font-size: 13px;
            transition: background 0.2s;
        }
        .btn-result:hover {
            background: #219150;
            color: #ffffff;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">
        <h2>Exam ERP Login</h2>
        <p class="login-subtitle">Sign in to your account</p>

        <?php if ($error !== ''): ?>
            <div class="alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php" autocomplete="off">
            <div class="form-group">
                <label for="username">Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                    placeholder="Enter username"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter password"
                    required
                >
            </div>

            <button type="submit" name="submit" class="btn-login">Login</button>
        </form>

        <div class="divider">
            <span>OR</span>
        </div>

        <div class="result-box">
            <p>Check Student Exam Result without login:</p>
            <a href="result.php" class="btn-result">&#128269; Check Result by Roll No</a>
        </div>
    </div>
</div>

</body>
</html>
