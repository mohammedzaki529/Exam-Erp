<?php
// manage_marks.php - View and Manage Exam Marks
require_once 'db.php';

$message = "";

// Delete Marks Entry
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    if ($delId > 0) {
        if ($conn->query("DELETE FROM exam_results WHERE result_id = $delId")) {
            $message = "<div class='alert-success'>Marks entry deleted successfully!</div>";
        } else {
            $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}

// Fetch all marks records
$query = "
    SELECT er.*, s.name as student_name, s.roll_number, sub.subject_name, sub.semester, c.course_name
    FROM exam_results er
    JOIN students s ON er.student_id = s.student_id
    JOIN subjects sub ON er.subject_id = sub.subject_id
    LEFT JOIN courses c ON s.course_id = c.course_id
    ORDER BY s.roll_number ASC, sub.semester ASC, sub.subject_name ASC
";
$results = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Marks - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h2>Exam Marks Directory</h2>
        <a href="marks.php" class="btn btn-success">+ Enter New Marks</a>
    </div>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <table>
        <thead>
            <tr>
                <th style="width: 40px;">ID</th>
                <th>Roll No</th>
                <th>Student Name</th>
                <th>Subject</th>
                <th>Sem</th>
                <th>Internal (30)</th>
                <th>External (70)</th>
                <th>Total (100)</th>
                <th>Grade</th>
                <th>Status</th>
                <th style="text-align: center; width: 140px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($results && $results->num_rows > 0): ?>
                <?php while ($r = $results->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $r['result_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($r['roll_number']); ?></strong></td>
                        <td><?php echo htmlspecialchars($r['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($r['subject_name']); ?></td>
                        <td><?php echo $r['semester']; ?></td>
                        <td><?php echo $r['internal_marks']; ?></td>
                        <td><?php echo $r['external_marks']; ?></td>
                        <td><strong><?php echo $r['total_marks']; ?></strong></td>
                        <td><strong><?php echo htmlspecialchars($r['grade']); ?></strong></td>
                        <td>
                            <?php if (strtolower($r['status']) == 'pass'): ?>
                                <span class="badge-pass">PASS</span>
                            <?php else: ?>
                                <span class="badge-fail">FAIL</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;">
                            <a href="edit_marks.php?id=<?php echo $r['result_id']; ?>" class="btn btn-sm btn-success">Edit</a>
                            <a href="manage_marks.php?delete=<?php echo $r['result_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this marks entry?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="11" style="text-align: center; color: #777; padding: 25px;">
                        No marks entries found. <a href="marks.php">Enter Marks Now &rarr;</a>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
