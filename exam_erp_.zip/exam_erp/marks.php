<?php
// marks.php - Enter Student Exam Marks
require_once 'db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $subject_id = (int)($_POST['subject_id'] ?? 0);
    $internal = (int)($_POST['internal_marks'] ?? 0);
    $external = (int)($_POST['external_marks'] ?? 0);

    // Limit values
    if ($internal < 0) $internal = 0;
    if ($internal > 30) $internal = 30;
    if ($external < 0) $external = 0;
    if ($external > 70) $external = 70;

    if ($student_id <= 0 || $subject_id <= 0) {
        $message = "<div class='alert-danger'>Please select both Student and Subject!</div>";
    } else {
        $total = $internal + $external;

        // Simple Grade and Status calculation
        if ($internal < 10 || $external < 25 || $total < 40) {
            $status = "Fail";
            $grade = "F";
        } else {
            $status = "Pass";
            if ($total >= 85) $grade = "A+";
            elseif ($total >= 75) $grade = "A";
            elseif ($total >= 60) $grade = "B";
            elseif ($total >= 50) $grade = "C";
            else $grade = "D";
        }

        // Check if marks entry already exists
        $check = $conn->query("SELECT result_id FROM exam_results WHERE student_id = $student_id AND subject_id = $subject_id");
        if ($check && $check->num_rows > 0) {
            $sql = "UPDATE exam_results SET internal_marks = $internal, external_marks = $external, total_marks = $total, grade = '$grade', status = '$status' WHERE student_id = $student_id AND subject_id = $subject_id";
            if ($conn->query($sql)) {
                $message = "<div class='alert-success'>Existing marks updated! Total: $total/100 | Grade: $grade | Status: $status (<a href='manage_marks.php'>View All Marks</a>)</div>";
            } else {
                $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
            }
        } else {
            $sql = "INSERT INTO exam_results (student_id, subject_id, internal_marks, external_marks, total_marks, grade, status) VALUES ($student_id, $subject_id, $internal, $external, $total, '$grade', '$status')";
            if ($conn->query($sql)) {
                $message = "<div class='alert-success'>Marks saved successfully! Total: $total/100 | Grade: $grade | Status: $status (<a href='manage_marks.php'>View All Marks</a>)</div>";
            } else {
                $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
            }
        }
    }
}

// Fetch Students
$students = $conn->query("SELECT student_id, name, roll_number FROM students ORDER BY roll_number ASC");

// Fetch Subjects
$subjects = $conn->query("SELECT s.subject_id, s.subject_name, s.semester, c.course_name FROM subjects s LEFT JOIN courses c ON s.course_id = c.course_id ORDER BY s.course_id ASC, s.semester ASC, s.subject_name ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Enter Exam Marks - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container" style="max-width: 520px;">
    <h2>Enter Student Exam Marks</h2>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <form method="POST" action="marks.php">
        <div class="form-group">
            <label>Select Student:</label>
            <select name="student_id" required>
                <option value="">-- Choose Student --</option>
                <?php while ($st = $students->fetch_assoc()): ?>
                    <option value="<?php echo $st['student_id']; ?>">
                        <?php echo $st['roll_number']; ?> - <?php echo $st['name']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Subject:</label>
            <select name="subject_id" required>
                <option value="">-- Choose Subject --</option>
                <?php while ($sub = $subjects->fetch_assoc()): ?>
                    <option value="<?php echo $sub['subject_id']; ?>">
                        <?php echo $sub['subject_name']; ?> (Sem <?php echo $sub['semester']; ?> - <?php echo $sub['course_name']; ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Internal Marks (Max 30, Passing: 10):</label>
            <input type="number" name="internal_marks" min="0" max="30" value="0" required>
        </div>

        <div class="form-group">
            <label>External / Theory Marks (Max 70, Passing: 25):</label>
            <input type="number" name="external_marks" min="0" max="70" value="0" required>
        </div>

        <div style="margin-top: 20px;">
            <input type="submit" value="Save Marks" class="btn btn-success">
            <a href="manage_marks.php" class="btn btn-secondary">View Marks List</a>
        </div>
    </form>
</div>

</body>
</html>
