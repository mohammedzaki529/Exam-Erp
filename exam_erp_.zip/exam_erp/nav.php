<div class="navbar">
    <a href="index.php">Dashboard</a>
    <a href="add_student.php">Add Student</a>
    <a href="students.php">Students List</a>
    <a href="subjects.php">Subjects</a>
    <a href="marks.php">Enter Marks</a>
    <a href="manage_marks.php">Marks List</a>
    <a href="result.php">Search Result</a>
</div>
