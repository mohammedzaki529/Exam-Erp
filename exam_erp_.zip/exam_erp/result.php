<?php
// result.php - Student Result Search and Marksheet
require_once 'db.php';

$searchedRoll = trim($_GET['roll'] ?? '');
$student = null;
$results = [];
$errorMsg = '';
$grandTotal = 0;
$maxMarks = 0;
$allPass = true;

if (!empty($searchedRoll)) {
    // Fetch Student
    $sql = "SELECT s.*, c.course_name 
            FROM students s 
            LEFT JOIN courses c ON s.course_id = c.course_id 
            WHERE s.roll_number = '$searchedRoll' 
            LIMIT 1";
    $stRes = $conn->query($sql);

    if ($stRes && $stRes->num_rows > 0) {
        $student = $stRes->fetch_assoc();
        $student_id = $student['student_id'];

        // Fetch Marks
        $mSql = "SELECT er.*, sub.subject_name 
                 FROM exam_results er 
                 JOIN subjects sub ON er.subject_id = sub.subject_id 
                 WHERE er.student_id = $student_id 
                 ORDER BY sub.subject_name ASC";
        $mRes = $conn->query($mSql);

        if ($mRes) {
            while ($row = $mRes->fetch_assoc()) {
                $results[] = $row;
                $grandTotal += (int)$row['total_marks'];
                $maxMarks += 100;
                if (strtolower($row['status']) != 'pass') {
                    $allPass = false;
                }
            }
        }
    } else {
        $errorMsg = "No record found for Roll Number: " . htmlspecialchars($searchedRoll);
    }
}

$percentage = ($maxMarks > 0) ? round(($grandTotal / $maxMarks) * 100, 2) : 0;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Student Result - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .marksheet {
            border: 2px solid #333333;
            padding: 20px;
            margin-top: 20px;
            background: #ffffff;
        }
        .marksheet-header {
            text-align: center;
            border-bottom: 2px solid #333333;
            padding-bottom: 12px;
            margin-bottom: 15px;
        }
        .meta-table {
            width: 100%;
            margin-bottom: 15px;
        }
        .meta-table td {
            border: none;
            padding: 5px 8px;
            font-size: 14px;
        }
        .summary-table {
            width: 100%;
            margin-top: 15px;
        }
        .summary-table td {
            text-align: center;
            padding: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container">
    <h2 class="no-print">Student Result Portal</h2>
    <hr class="no-print" style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <!-- Search Form -->
    <div class="no-print" style="margin-bottom: 20px;">
        <form method="GET" action="result.php" class="search-box">
            <input type="text" name="roll" placeholder="Enter Student Roll Number (e.g. 24BCA101)" value="<?php echo htmlspecialchars($searchedRoll); ?>" required>
            <button type="submit" class="btn">View Result</button>
        </form>
    </div>

    <?php if (!empty($errorMsg)): ?>
        <div class="alert-danger"><?php echo $errorMsg; ?></div>
    <?php endif; ?>

    <!-- Marksheet -->
    <?php if ($student): ?>
        <div class="marksheet">
            <div class="marksheet-header">
                <h2>COLLEGE EXAMINATION BOARD</h2>
                <h3>OFFICIAL STATEMENT OF MARKS</h3>
            </div>

            <!-- Student Info -->
            <table class="meta-table">
                <tr>
                    <td style="width: 20%;"><strong>Student Name:</strong></td>
                    <td style="width: 30%;"><?php echo htmlspecialchars($student['name']); ?></td>
                    <td style="width: 20%;"><strong>Roll Number:</strong></td>
                    <td style="width: 30%;"><?php echo htmlspecialchars($student['roll_number']); ?></td>
                </tr>
                <tr>
                    <td><strong>Course:</strong></td>
                    <td><?php echo htmlspecialchars($student['course_name'] ?? 'General'); ?></td>
                    <td><strong>Semester:</strong></td>
                    <td>Semester <?php echo $student['semester']; ?></td>
                </tr>
            </table>

            <!-- Marks Table -->
            <table>
                <thead>
                    <tr>
                        <th style="width: 40px;">#</th>
                        <th>Subject Name</th>
                        <th style="text-align: center;">Internal (30)</th>
                        <th style="text-align: center;">External (70)</th>
                        <th style="text-align: center;">Total (100)</th>
                        <th style="text-align: center;">Grade</th>
                        <th style="text-align: center;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($results)): ?>
                        <?php $sno = 1; foreach ($results as $r): ?>
                            <tr>
                                <td><?php echo $sno++; ?></td>
                                <td><strong><?php echo htmlspecialchars($r['subject_name']); ?></strong></td>
                                <td style="text-align: center;"><?php echo $r['internal_marks']; ?></td>
                                <td style="text-align: center;"><?php echo $r['external_marks']; ?></td>
                                <td style="text-align: center;"><strong><?php echo $r['total_marks']; ?></strong></td>
                                <td style="text-align: center;"><?php echo htmlspecialchars($r['grade']); ?></td>
                                <td style="text-align: center;">
                                    <?php if (strtolower($r['status']) == 'pass'): ?>
                                        <span class="badge-pass">PASS</span>
                                    <?php else: ?>
                                        <span class="badge-fail">FAIL</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 15px; color: #777;">
                                No marks recorded for this student yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Summary Table -->
            <?php if (!empty($results)): ?>
                <table class="summary-table">
                    <tr style="background: #f4f6f9;">
                        <td>Total Marks: <?php echo $grandTotal; ?> / <?php echo $maxMarks; ?></td>
                        <td>Percentage: <?php echo $percentage; ?>%</td>
                        <td>
                            Final Result: 
                            <?php if ($allPass): ?>
                                <span class="badge-pass">PASSED</span>
                            <?php else: ?>
                                <span class="badge-fail">FAILED</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>
        </div>

        <div class="no-print" style="margin-top: 15px; text-align: right;">
            <button onclick="window.print()" class="btn btn-success">Print Marksheet</button>
            <a href="result.php" class="btn btn-secondary">New Search</a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
