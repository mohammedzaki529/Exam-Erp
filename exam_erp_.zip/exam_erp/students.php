<?php
// students.php - View and Manage Students List
require_once 'db.php';

$message = "";

// Delete Student
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id > 0) {
        $conn->query("DELETE FROM exam_results WHERE student_id = $id");
        $conn->query("DELETE FROM students WHERE student_id = $id");
        $message = "<div class='alert-success'>Student and associated marks deleted successfully!</div>";
    }
}

// Search Filter
$search = trim($_GET['search'] ?? '');
if (!empty($search)) {
    $sql = "SELECT s.*, c.course_name 
            FROM students s 
            LEFT JOIN courses c ON s.course_id = c.course_id 
            WHERE s.name LIKE '%$search%' OR s.roll_number LIKE '%$search%' 
            ORDER BY s.student_id DESC";
} else {
    $sql = "SELECT s.*, c.course_name 
            FROM students s 
            LEFT JOIN courses c ON s.course_id = c.course_id 
            ORDER BY s.student_id DESC";
}
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Students - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h2>Students List</h2>
        <a href="add_student.php" class="btn btn-success">+ Add New Student</a>
    </div>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <!-- Search Form -->
    <form method="GET" action="students.php" class="search-box">
        <input type="text" name="search" placeholder="Search by Student Name or Roll Number..." value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit" class="btn">Search</button>
        <?php if (!empty($search)): ?>
            <a href="students.php" class="btn btn-secondary">Clear</a>
        <?php endif; ?>
    </form>

    <!-- Students Table -->
    <table>
        <thead>
            <tr>
                <th style="width: 50px;">ID</th>
                <th>Roll Number</th>
                <th>Student Name</th>
                <th>Course</th>
                <th>Semester</th>
                <th style="text-align: center; width: 220px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['student_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['roll_number']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['course_name'] ?? 'Not Assigned'); ?></td>
                        <td>Semester <?php echo $row['semester']; ?></td>
                        <td style="text-align: center;">
                            <a href="result.php?roll=<?php echo urlencode($row['roll_number']); ?>" class="btn btn-sm">Result</a>
                            <a href="edit_student.php?id=<?php echo $row['student_id']; ?>" class="btn btn-sm btn-success">Edit</a>
                            <a href="students.php?delete=<?php echo $row['student_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this student?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align: center; color: #777; padding: 20px;">No students found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
