<?php
// Redirect to full subjects CRUD manager
header("Location: subjects.php");
exit;
