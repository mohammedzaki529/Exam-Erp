<?php
// subjects.php - Manage Subjects (Add & View)
require_once 'db.php';

$message = "";

// Delete Subject
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id > 0) {
        $conn->query("DELETE FROM exam_results WHERE subject_id = $id");
        $conn->query("DELETE FROM subjects WHERE subject_id = $id");
        $message = "<div class='alert-success'>Subject deleted successfully!</div>";
    }
}

// Add Subject
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_subject'])) {
    $subject_name = trim($_POST['subject_name'] ?? '');
    $course_id = (int)($_POST['course_id'] ?? 0);
    $semester = (int)($_POST['semester'] ?? 1);

    if (empty($subject_name) || $course_id <= 0) {
        $message = "<div class='alert-danger'>Please enter subject name and choose a course!</div>";
    } else {
        $sql = "INSERT INTO subjects (subject_name, course_id, semester) VALUES ('$subject_name', $course_id, $semester)";
        if ($conn->query($sql)) {
            $message = "<div class='alert-success'>Subject added successfully!</div>";
        } else {
            $message = "<div class='alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}

// Fetch Courses
$courses = $conn->query("SELECT * FROM courses ORDER BY course_name ASC");

// Fetch Subjects
$subjects = $conn->query("
    SELECT s.*, c.course_name 
    FROM subjects s 
    LEFT JOIN courses c ON s.course_id = c.course_id 
    ORDER BY s.course_id ASC, s.semester ASC, s.subject_name ASC
");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Subjects - Exam ERP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'nav.php'; ?>

<div class="container">
    <h2>Course Subjects Management</h2>
    <hr style="border: 0; border-top: 1px solid #ddd; margin-bottom: 20px;">

    <?php echo $message; ?>

    <!-- Add Subject Form -->
    <div style="background: #fdfefe; border: 1px solid #ddd; padding: 15px; margin-bottom: 25px;">
        <h3>Add New Subject</h3>
        <form method="POST" action="subjects.php">
            <input type="hidden" name="add_subject" value="1">
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div style="flex: 2; min-width: 200px;">
                    <label>Subject Name:</label>
                    <input type="text" name="subject_name" required placeholder="e.g. Data Structures">
                </div>
                <div style="flex: 2; min-width: 200px;">
                    <label>Course:</label>
                    <select name="course_id" required>
                        <option value="">-- Select Course --</option>
                        <?php 
                        // reset pointer
                        $courses->data_seek(0);
                        while ($c = $courses->fetch_assoc()): 
                        ?>
                            <option value="<?php echo $c['course_id']; ?>">
                                <?php echo $c['course_name']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div style="flex: 1; min-width: 120px;">
                    <label>Semester:</label>
                    <select name="semester" required>
                        <option value="1">1st Sem</option>
                        <option value="2">2nd Sem</option>
                        <option value="3">3rd Sem</option>
                        <option value="4">4th Sem</option>
                        <option value="5">5th Sem</option>
                        <option value="6">6th Sem</option>
                    </select>
                </div>
                <div style="flex: 1; min-width: 120px; display: flex; align-items: flex-end;">
                    <input type="submit" value="+ Add Subject" class="btn btn-success" style="width: 100%;">
                </div>
            </div>
        </form>
    </div>

    <!-- Subjects List Table -->
    <h3>Registered Subjects List</h3>
    <table>
        <thead>
            <tr>
                <th style="width: 50px;">ID</th>
                <th>Subject Name</th>
                <th>Course</th>
                <th>Semester</th>
                <th style="text-align: center; width: 150px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($subjects && $subjects->num_rows > 0): ?>
                <?php while ($s = $subjects->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $s['subject_id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($s['subject_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($s['course_name'] ?? 'N/A'); ?></td>
                        <td>Semester <?php echo $s['semester']; ?></td>
                        <td style="text-align: center;">
                            <a href="edit_subject.php?id=<?php echo $s['subject_id']; ?>" class="btn btn-sm btn-success">Edit</a>
                            <a href="subjects.php?delete=<?php echo $s['subject_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this subject?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center; color: #777; padding: 20px;">No subjects found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
