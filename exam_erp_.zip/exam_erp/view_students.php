<?php
// view_students.php - Redirect to main students CRUD manager
header("Location: students.php");
exit;
